
package practica1pspmaria;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Empleado {
    
    private String Nombre;
    private String fechaNac;
    private double salario;

    public Empleado(String Nombre, String fechaNac, double salario) {
        this.Nombre = Nombre;
        this.fechaNac = fechaNac;
        this.salario = salario;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(String fechaNac) {
        this.fechaNac = fechaNac;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    
    
   
}
