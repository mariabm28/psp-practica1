/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica1pspmaria;

import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;

import java.text.*;
import java.util.*;
import java.util.List;


public class Empresa extends JFrame
{
    
    //Valores para los campos de texto
    private String nombre;
    private String fecha;
    private double salario;
    

    //Etiquetas para identificar los campos de texto
    private JLabel nombreLabel;
    private JLabel fechaLabel;
    private JLabel salarioLabel;

    //Cadenas para las etiquetas
    private static String nombreString = "Nombre: ";
    private static String fechaString = "Fecha Nacimiento: ";
    private static String salarioString = "Salario: ";
    
    //Text fields para introducir datos
    private TextField nombreField;
    private TextField fechaField;
    private TextField salarioField;
      
    //botones
    private JButton anterior;
    private JButton siguiente;
    private JButton principio;
    private JButton ultimo;
    private JButton alta;
    private JButton cancelar;
    
    //Lista de empleados
    private List<Empleado> listaEmple; 
    
    //indice de empleado para la lista
    private int indice=0;
    
  

    public Empresa() {
        
        super("Empresa");
        
        //Crea empleados que se añade al ArrayList
        listaEmple = new ArrayList<>();
        listaEmple.add(new Empleado("Juan Gonzalez","02/05/1995" ,1255.50));
        listaEmple.add(new Empleado("Ana Lopez","28/08/1991", 1789.23));
        listaEmple.add(new Empleado("David Cruz","22/03/1994", 1452.36));
        listaEmple.add(new Empleado("Carlos Rivas","08/11/1998", 1848.45));
        listaEmple.add(new Empleado("Elena Garcia","12/09/1993", 1354.28));
        
        //Crea las etiquetas.
        nombreLabel = new JLabel(nombreString);
        fechaLabel = new JLabel(fechaString);
        salarioLabel = new JLabel(salarioString);

        //Crea los campos, con su longitud         
        nombreField = new TextField(20);
        fechaField = new TextField(12);
        salarioField = new TextField(8);
        
        //Crea los botones con sus nombres
        principio = new JButton("Principio"); 
        anterior = new JButton("Anterior"); 
        siguiente = new JButton("Siguiente"); 
        ultimo = new JButton("Último"); 
        alta= new JButton("Alta");
        cancelar= new JButton("Cancelar");
        
        //Para que no se pueda modificar
        nombreField.setEditable(false);
        fechaField.setEditable(false);
        salarioField.setEditable(false); 
        
        //Se pone un titutlo
        setTitle("Listado de empleados");

        //Dispone la geometría de las etiquetas en un panel
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(3, 2));
        labelPane.add(nombreLabel);
        labelPane.add(fechaLabel);
        labelPane.add(salarioLabel);
        
        //Cambiar el color de fondo del labelpane(fond0 de las etiquetas)
        Color celesteClaro = new Color(187, 235, 254  );  // Definir un color celeste claro personalizado
        labelPane.setBackground(celesteClaro);

        //Dispone los campos de texto en otro panel
        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(3, 2));
        fieldPane.add(nombreField);
        fieldPane.add(fechaField);
        fieldPane.add(salarioField);
       
        
        //Dispone de los botones en otro panel
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new FlowLayout());
        panelBotones.add(principio);
        panelBotones.add(anterior);
        panelBotones.add(siguiente);
        panelBotones.add(ultimo);
        panelBotones.add(alta);
        panelBotones.add(cancelar);
       
        //Cambiar color de fonde del panel de botones
        panelBotones.setBackground(celesteClaro);

        //Incluye los tres paneles en otro panel,
        //etiquetas a la izquierda
        // campos de texto a la derecha
        //y botones abajo
        JPanel contentPane = new JPanel();
        contentPane.setBorder( BorderFactory.createEmptyBorder(40, 40, 40, 40));
        contentPane.setLayout(new BorderLayout());
        contentPane.add(labelPane, BorderLayout.WEST);
        contentPane.add(fieldPane, BorderLayout.CENTER);
        contentPane.add(panelBotones, BorderLayout.SOUTH);
        
        // Cambiar el color de fondo del contentPane (fondo de la ventana)
        contentPane.setBackground(celesteClaro);
        
        // Establecer el color de los botones en rosa
        Color rosa = new Color(253, 216, 228 );
        principio.setBackground(rosa);
        anterior.setBackground(rosa);
        siguiente.setBackground(rosa);
        ultimo.setBackground(rosa);
        alta.setBackground(rosa);
        cancelar.setBackground(rosa);
       
        setContentPane(contentPane);  //this.setContentPane(contentPane);
          // es set, o sea, machado el contenedor del objeto "Doble", hijo de JFrame
          
       
        //para mostrar el primer empleado
        mostrarEmpleado();
         
        //los botones alta y cancelar los desactivamos
        alta.setEnabled(false);
        cancelar.setEnabled(false);
         
         
       //agregamos funcionabilidad al boton siguiente
        siguiente.addActionListener(new ActionListener(){
            
            public void actionPerformed(ActionEvent e) {
                if(indice<listaEmple.size()-1){
                    anterior.setEnabled(true);// cuando llega al primero y se le da al boton anterior o principio, se desactiva y asi vuelve a activarse
                    principio.setEnabled(true);
                    mostrarSiguienteEmpleado();
                    
                }else{//si llegamos al final de la lista, se abre un alta nueva 
                   alta.setEnabled(true);//activamos los botones alta y cancelar
                   cancelar.setEnabled(true);
                   anterior.setEnabled(false);//desactivamos el resto de los botones
                   siguiente.setEnabled(false);
                   principio.setEnabled(false);
                   ultimo.setEnabled(false);
                   altaNueva(); 
                }             
                
            }       
         });
        
      //agregamos funcionabilidad al boton anterior
        anterior.addActionListener(new ActionListener(){
            
            public void actionPerformed(ActionEvent e) {
                
                if(indice>0){ 
                  
                 mostrarAnteriorEmpleado();
                 ultimo.setEnabled(true); //cuando llega al ultimo el boton anterior y principio se desactivan tambien y para que no pase eso se vuelve a activar el boton ultimo
                 
                }else{
                    anterior.setEnabled(false); //desactivamos los botones anterior y principio cuando llega al primer empleado
                    principio.setEnabled(false);
                }
            }
         });
        
        //agregamos funcionabilidad al boton principio
        principio.addActionListener(new ActionListener(){
            
            public void actionPerformed(ActionEvent e) {
                mostrarPrimero();
                principio.setEnabled(false);//desactivamos los botones anterior y principio cuando llega al primer empleado
                anterior.setEnabled(false);
            }
        });
        
        //agregamos funcionabilidad al boton ultimo
        ultimo.addActionListener(new ActionListener(){
            
            public void actionPerformed(ActionEvent e) {
                mostrarUltimo();
                ultimo.setEnabled(false); //desactivamos el boton ultimo cuando llegamos al utlimo empleado
            }
        });
        
         //agregamos funcionabilidad al boton cancelar
        cancelar.addActionListener(new ActionListener(){
            
            public void actionPerformed(ActionEvent e) {
                //activamos todos los botones menos el de alta y cancelar que lo desactivamos
                principio.setEnabled(true); 
                anterior.setEnabled(true); 
                siguiente.setEnabled(true); 
                ultimo.setEnabled(true); 
                alta.setEnabled(false); 
                cancelar.setEnabled(false); 
                
                //Ponemos el indice a 0 para que se muestre los empleados desde el principio
                indice=0;
                
                //volvemos a mostrar los empleados
                mostrarEmpleado();
                
                //Para que no se pueda modificar
                nombreField.setEditable(false);
                fechaField.setEditable(false);
                salarioField.setEditable(false);
            }
        });

    }
    
    private void mostrarUltimo(){
      indice=listaEmple.size()-1;
      mostrarEmpleado();
    
    }
    
    private void mostrarPrimero(){
      indice=0;
      mostrarEmpleado();
    }
    
        
    private void altaNueva(){
     //Para que salgan los campos en blancos   
     nombreField.setText("");
     fechaField.setText("");
     salarioField.setText("");   
        
     //Para que se pueda escribir
     nombreField.setEditable(true);
     fechaField.setEditable(true);
     salarioField.setEditable(true);
     
     //agregamos funcionabilidad al boton alta
     alta.addActionListener(new ActionListener(){
         
         public void actionPerformed(ActionEvent e) {
            String nombre = nombreField.getText();
            String fecha = fechaField.getText();
            double salario = Double.parseDouble(salarioField.getText());
            
            //Creamos un nuevo empleado
            Empleado empleadoNuevo= new Empleado(nombre, fecha,salario);
            
            // Añadir el nuevo empleado a la lista
            listaEmple.add(empleadoNuevo);
            
            //Para que salgan los campos en blancos  
            nombreField.setText("");
            fechaField.setText("");
            salarioField.setText("");
         }
     });
    }
    
    private void mostrarAnteriorEmpleado(){
     indice--;
     mostrarEmpleado();
    
    }
    
    private void mostrarSiguienteEmpleado(){
     indice++;
     mostrarEmpleado();
    
    }
    
    private void mostrarEmpleado(){
     
       if(indice>=0 && indice<listaEmple.size()){
           Empleado empleado= listaEmple.get(indice);
           nombreField.setText(empleado.getNombre());
           fechaField.setText(empleado.getFechaNac());
           salarioField.setText(String.valueOf(empleado.getSalario()));
       
       }
    
    }

    public static void main(String[] args) {
        
        final Empresa app = new Empresa();

        //Lo que pasa si cerramos la ventana
        app.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }

        });
          
        //Ajusta la ventana automaticamente en funcion de los elementos
        app.pack();
        //Para que la ventana salga por pantalla
        app.setVisible(true);
        
     }
   
}


